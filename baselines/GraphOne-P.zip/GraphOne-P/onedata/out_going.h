#pragma once

inline vid_t get_vcount(tid_t tid) 
{ 
    return g->get_type_vcount(tid);
}
